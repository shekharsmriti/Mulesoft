package com.cg.webservice;

import javax.jws.WebService;

@WebService
public class SoapImpl implements ISoap{

	@Override
	public String sayHello(String name) {
		System.out.println("Hello SOAP Service");
		
		return "Hello" +name ;
	}

	
	

}
