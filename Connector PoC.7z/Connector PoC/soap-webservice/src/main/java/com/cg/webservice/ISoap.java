package com.cg.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;



@WebService
public interface ISoap {

@WebMethod	
public String sayHello(String name);


}
