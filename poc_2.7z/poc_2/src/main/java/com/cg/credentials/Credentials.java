package com.cg.credentials;



import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;
import org.mule.extension.annotations.Configuration;



@Configuration
public class Credentials implements Callable {
private int id;
private String userName;
private String password;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public Credentials(int id, String userName, String password) {
	super();
	this.id = id;
	this.userName = userName;
	this.password = password;
}

public Credentials() {
	super();
}


@Override
public Object onCall(MuleEventContext eventContext) throws Exception {
	String inputId=eventContext.getMessage().getInvocationProperty("Id");
	String inputUserName=eventContext.getMessage().getInvocationProperty("UserName");
	String inputPassword=eventContext.getMessage().getInvocationProperty("Password");
	
	String pId=eventContext.getMessage().getInvocationProperty("propertyId");
	String pUserName=eventContext.getMessage().getInvocationProperty("propertyUserName");
	String pPassword=eventContext.getMessage().getInvocationProperty("propertyPassword");
	
	System.out.println("Id" +inputId  + "UserName" +inputUserName  + "Password" +inputPassword  );
	System.out.println("propertyId" +pId  + "propertyUserName" +pUserName  + "propertyPassword" + pPassword);
	if((inputId.equals(pId))&&(inputUserName.equals(pUserName))&&(inputPassword.equals(pPassword)))
	{
		
		return ("Login sucessful");
	}
	
	
		else
		{
			return ("Login failed");
		}
	
			
}
}

